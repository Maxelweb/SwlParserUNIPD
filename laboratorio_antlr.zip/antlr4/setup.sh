#!/bin/sh
export PATH=$PATH:$PWD/bin
export CPLUS_INCLUDE_PATH=${CPLUS_INCLUDE_PATH}:$PWD/include
export LD_LIBRARY_PATH=${LD_LIBRARY_PATH}:$PWD/lib

